"""Lambda handler for h1_aws_sync_ingest.

Entry point for AWS Lambda. Calls sync_telemetry.run() with dry_run=False
and returns the sync result as JSON.
"""

import json
import os
import sys

# Ensure the packaged h1_aws_sync module is importable
sys.path.insert(0, os.path.dirname(__file__))

from h1_aws_sync.sync_telemetry import run
from h1_aws_sync.config import load_config


def handler(event, context):
    """AWS Lambda handler.

    Args:
        event: Lambda event dict (unused, reserved for future config override).
        context: Lambda context object.

    Returns:
        dict with statusCode and body (JSON string of sync summary).
    """
    try:
        # Load config from packaged aws_sync.yaml (with env var overrides)
        config_path = os.environ.get('AWS_SYNC_CONFIG_PATH')
        cfg = load_config(config_path)

        # Allow event to override data_dir (for testing)
        data_dir = event.get('data_dir') if isinstance(event, dict) else None

        # Run the sync (NOT dry-run - this is the production Lambda)
        summary = run(cfg, data_dir=data_dir, dry_run=False)

        return {
            'statusCode': 200,
            'body': json.dumps(summary)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
